'use strict';

/**
 * @ngdoc function
 * @name ecitaApp.controller:EmpresaFacturasCtrl
 * @description
 * # EmpresaFacturasCtrl
 * Controller of the ecitaApp
 */
angular.module('ecitaApp')
  .controller('EmpresaFacturasCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
