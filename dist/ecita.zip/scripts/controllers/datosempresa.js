'use strict';

/**
 * @ngdoc function
 * @name ecitaApp.controller:DatosempresaCtrl
 * @description
 * # DatosempresaCtrl
 * Controller of the ecitaApp
 */
angular.module('ecitaApp')
  .controller('DatosEmpresaCtrl', function ($state) {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];

  
  });
