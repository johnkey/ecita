'use strict';

/**
 * @ngdoc function
 * @name ecitaApp.controller:EmpresaFacturasDetalleCtrl
 * @description
 * # EmpresaFacturasDetalleCtrl
 * Controller of the ecitaApp
 */
angular.module('ecitaApp')
  .controller('EmpresaFacturasDetalleCtrl',function () {
    
    	
  });
